var pictureBookData = {
    "pictureBookId": "9780170394703_TheLionandtheRabbit-test",
    "audio": "./resource/9780170394703_the_lion_and_the_rabbit.mp3",
    "images": ["./resource/jpg\\b-01.jpg", "./resource/jpg\\b-02.jpg", "./resource/jpg\\b-03.jpg", "./resource/jpg\\b-04.jpg", "./resource/jpg\\b-05.jpg", "./resource/jpg\\b-06.jpg", "./resource/jpg\\b-07.jpg", "./resource/jpg\\b-08.jpg", "./resource/jpg\\b-09.jpg", "./resource/jpg\\b-10.jpg", "./resource/jpg\\b-11.jpg", "./resource/jpg\\b-12.jpg", "./resource/jpg\\b-13.jpg", "./resource/jpg\\b-14.jpg", "./resource/jpg\\b-15.jpg", "./resource/jpg\\b-16.jpg"],
    "cover": ["./resource/jpg\\a-1.jpg"]
}